<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
  * {
    margin: 0;
    padding: 0;
  } 
  a {
    text-decoration: none;
    color: black;
  }
  ul,
  li {
    list-style: none;
  }
  div {
    box-sizing: border-box;
  }
</style>
